import React from 'react';

export default function HomePage() {
  return (
    <div className="page-container">
      <div className="banner-box">
        <h2 className="banner-title">Welcome to Nexus Digital Campus Platform</h2>
        <p className="banner-desc">
          Task 1 Complete: The foundational React + Vite application structure has been initialized successfully. 
          Ready for subsequent component & feature developments.
        </p>
      </div>

      <div className="page-header">
        <h3 className="page-title">Platform Architecture Modules</h3>
        <p className="page-subtitle">Core module placeholders established for upcoming hackathon development tasks.</p>
      </div>

      <div className="card-grid">
        <div className="card">
          <div className="card-title">🏢 Facility Management</div>
          <p className="card-text">
            Structure reserved for room bookings, resource allocation, and smart facility monitoring.
          </p>
        </div>

        <div className="card">
          <div className="card-title">📅 Academic & Events</div>
          <p className="card-text">
            Structure reserved for campus schedules, hackathon events, and lecture hall announcements.
          </p>
        </div>

        <div className="card">
          <div className="card-title">🛡️ Campus Security & Access</div>
          <p className="card-text">
            Structure reserved for digital ID verification and real-time gate pass management.
          </p>
        </div>
      </div>
    </div>
  );
}
