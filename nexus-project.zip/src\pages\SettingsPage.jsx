import React from 'react';

export default function SettingsPage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h2 className="page-title">Application Settings</h2>
        <p className="page-subtitle">Manage environment settings, themes, and system configurations.</p>
      </div>

      <div className="card">
        <div className="card-title">Environment Information</div>
        <p className="card-text">
          Framework: React 19 + Vite<br />
          Status: Basic Structure Initialized (Task 1)
        </p>
      </div>
    </div>
  );
}
