import React from 'react';
import { upcomingExams } from '../data/demoData';

export default function ExamsSection({ limit }) {
  const items = limit ? upcomingExams.slice(0, limit) : upcomingExams;

  return (
    <div className="dashboard-section-card">
      <div className="section-card-header">
        <div>
          <h3 className="section-title">🎯 Examination Schedule</h3>
          <p className="section-subtitle">Official semester exam dates, timings, and hall allocations</p>
        </div>
        <span className="badge badge-info">{upcomingExams.length} Scheduled</span>
      </div>

      <div className="exams-grid">
        {items.map((exam) => (
          <div key={exam.id} className="exam-card">
            <div className="exam-card-top">
              <span className="exam-code-badge">{exam.code}</span>
              <span className="badge badge-secondary">{exam.weightage}</span>
            </div>
            
            <h4 className="exam-title">{exam.subject}</h4>
            
            <div className="exam-details">
              <div className="exam-detail-item">
                <span className="detail-icon">📅</span>
                <span><strong>Date:</strong> {exam.date}</span>
              </div>
              <div className="exam-detail-item">
                <span className="detail-icon">⏰</span>
                <span><strong>Time:</strong> {exam.time}</span>
              </div>
              <div className="exam-detail-item">
                <span className="detail-icon">🏢</span>
                <span><strong>Room / Venue:</strong> {exam.room}</span>
              </div>
            </div>

            <div className="exam-syllabus-box">
              <span className="syllabus-title">Syllabus Scope:</span>
              <span className="syllabus-desc">{exam.syllabus}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
