import React from 'react';
import { todaysTimetable } from '../data/demoData';

export default function TimetableSection({ limit }) {
  const items = limit ? todaysTimetable.slice(0, limit) : todaysTimetable;

  return (
    <div className="dashboard-section-card">
      <div className="section-card-header">
        <div>
          <h3 className="section-title">📅 Today's Timetable</h3>
          <p className="section-subtitle">Real-time schedule for current academic sessions</p>
        </div>
        <span className="badge badge-primary">{todaysTimetable.length} Sessions Today</span>
      </div>

      <div className="timetable-list">
        {items.map((session) => {
          const isHighlighted = session.isCurrent || session.isNext;

          return (
            <div 
              key={session.id} 
              className={`timetable-item ${session.isCurrent ? 'class-current' : ''} ${session.isNext ? 'class-next' : ''}`}
            >
              <div className="time-col">
                <span className="time-text">{session.time}</span>
                <span className="course-code-badge">{session.code}</span>
              </div>

              <div className="details-col">
                <div className="subject-title-row">
                  <h4 className="subject-name">{session.subject}</h4>
                  {session.isCurrent && (
                    <span className="badge badge-primary highlight-pill">⚡ CURRENT CLASS</span>
                  )}
                  {session.isNext && (
                    <span className="badge badge-info highlight-pill">▶ NEXT UP</span>
                  )}
                </div>
                <div className="meta-row">
                  <span className="meta-item">📍 <strong>Room:</strong> {session.room}</span>
                  <span className="meta-item">👨‍🏫 <strong>Faculty:</strong> {session.faculty}</span>
                  <span className="meta-item type-item">{session.type}</span>
                </div>
              </div>

              <div className="status-col">
                <span className={`status-pill status-${session.statusType}`}>
                  {session.status}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
