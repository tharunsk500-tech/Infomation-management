import React, { useState } from 'react';
import { campusAnnouncements } from '../data/demoData';

export default function AnnouncementsSection({ showFilter = false, limit }) {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = ['All', 'Hackathon', 'Academic', 'Notice', 'Event'];

  const filteredItems = campusAnnouncements.filter((news) => {
    if (selectedCategory === 'All') return true;
    return news.category.toLowerCase() === selectedCategory.toLowerCase();
  });

  const displayItems = limit ? filteredItems.slice(0, limit) : filteredItems;

  return (
    <div className="dashboard-section-card">
      <div className="section-card-header">
        <div>
          <h3 className="section-title">📢 Campus Announcements</h3>
          <p className="section-subtitle">Official administrative notices, event invites, and departmental news</p>
        </div>

        {showFilter && (
          <div className="filter-button-group">
            {categories.map((cat) => (
              <button
                key={cat}
                className={`filter-btn ${selectedCategory === cat ? 'active' : ''}`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="announcements-list">
        {displayItems.length === 0 ? (
          <div className="empty-state-box">No announcements in category "{selectedCategory}".</div>
        ) : (
          displayItems.map((news) => (
            <div 
              key={news.id} 
              className={`announcement-item ${news.isImportant ? 'announcement-important' : ''}`}
            >
              <div className="announcement-top">
                <div className="announcement-badge-row">
                  <span className={`badge badge-${news.categoryType}`}>
                    {news.category}
                  </span>
                  {news.isImportant && (
                    <span className="badge badge-urgent announcement-important-tag">
                      🚨 IMPORTANT NOTICE
                    </span>
                  )}
                </div>
                <span className="announcement-date">{news.date} &bull; {news.author}</span>
              </div>
              
              <h4 className="announcement-headline">{news.title}</h4>
              <p className="announcement-summary">{news.summary}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
