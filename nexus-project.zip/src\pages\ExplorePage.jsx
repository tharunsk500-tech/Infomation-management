import React from 'react';

export default function ExplorePage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h2 className="page-title">Campus Directory</h2>
        <p className="page-subtitle">Placeholder for exploring departments, laboratories, and student services.</p>
      </div>

      <div className="card-grid">
        <div className="card">
          <div className="card-title">Computer Science Block</div>
          <p className="card-text">Main Tech Hub &bull; Labs 101 - 108</p>
        </div>
        <div className="card">
          <div className="card-title">Central Library</div>
          <p className="card-text">Knowledge Center &bull; Quiet Zone & Research</p>
        </div>
      </div>
    </div>
  );
}
