import React from 'react';

export default function Sidebar({ activeTab, setActiveTab, userRole }) {
  const allMenuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊', roles: ['student', 'admin'] },
    { id: 'admin-overview', label: 'Admin Overview', icon: '🛡️', roles: ['admin'], badge: 'ADMIN' },
    { id: 'timetable', label: 'Timetable', icon: '📅', roles: ['student', 'admin'] },
    { id: 'attendance', label: 'Attendance', icon: '📈', roles: ['student', 'admin'] },
    { id: 'assignments', label: 'Assignments', icon: '📝', roles: ['student', 'admin'] },
    { id: 'exams', label: 'Exams', icon: '🎯', roles: ['student', 'admin'] },
    { id: 'announcements', label: 'Announcements', icon: '📢', roles: ['student', 'admin'] },
    { id: 'ai-assistant', label: 'AI Assistant', icon: '🤖', roles: ['student', 'admin'], badge: 'AI' }
  ];

  const permittedItems = allMenuItems.filter((item) =>
    item.roles.includes(userRole || 'student')
  );

  return (
    <aside className="nexus-sidebar">
      <div>
        <div className="sidebar-section-title">MAIN NAVIGATION</div>
        <nav className="sidebar-nav">
          {permittedItems.map((item) => (
            <button
              key={item.id}
              className={`nav-item ${activeTab === item.id ? 'active' : ''}`}
              onClick={() => setActiveTab(item.id)}
            >
              <span className="nav-icon">{item.icon}</span>
              <span className="nav-label">{item.label}</span>
              {item.badge && <span className="nav-item-badge">{item.badge}</span>}
            </button>
          ))}
        </nav>
      </div>

      <div className="sidebar-footer-card">
        <div className="sidebar-card-title">Nexus OS</div>
        <div className="sidebar-card-desc">Role: {(userRole || 'student').toUpperCase()}</div>
      </div>
    </aside>
  );
}
