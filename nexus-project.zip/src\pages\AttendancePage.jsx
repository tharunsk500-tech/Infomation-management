import React from 'react';
import { attendanceData, studentProfile } from '../data/demoData';

export default function AttendancePage() {
  const totalClassesAttended = attendanceData.reduce((acc, curr) => acc + curr.presentClasses, 0);
  const totalClassesConducted = attendanceData.reduce((acc, curr) => acc + curr.totalClasses, 0);
  const overallPercentage = ((totalClassesAttended / totalClassesConducted) * 100).toFixed(1);
  const subjectsAtRisk = attendanceData.filter((item) => item.percentage < 75);

  return (
    <div className="page-container">
      <div className="page-header">
        <h2 className="page-title">Attendance Tracking & Eligibility</h2>
        <p className="page-subtitle">Official attendance records for {studentProfile.name} ({studentProfile.department})</p>
      </div>

      {/* Summary Metrics */}
      <div className="stats-grid" style={{ marginBottom: '2rem' }}>
        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Overall Attendance Rate</span>
            <span className="stat-icon">📊</span>
          </div>
          <div className="stat-value">{overallPercentage}%</div>
          <div className="stat-footer">
            <span className="stat-subtext">{totalClassesAttended} of {totalClassesConducted} total sessions attended</span>
            <span className="badge badge-primary">Good Standing</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Minimum Threshold</span>
            <span className="stat-icon">🛡️</span>
          </div>
          <div className="stat-value">75.0%</div>
          <div className="stat-footer">
            <span className="stat-subtext">Mandatory for exam hall ticket eligibility</span>
            <span className="badge badge-secondary">Campus Rule</span>
          </div>
        </div>

        <div className="stat-card">
          <div className="stat-header">
            <span className="stat-title">Courses at Risk (&lt;75%)</span>
            <span className="stat-icon">⚠️</span>
          </div>
          <div className="stat-value" style={{ color: subjectsAtRisk.length > 0 ? '#f87171' : 'white' }}>
            {subjectsAtRisk.length} Course{subjectsAtRisk.length === 1 ? '' : 's'}
          </div>
          <div className="stat-footer">
            <span className="stat-subtext">{subjectsAtRisk.length > 0 ? 'Requires immediate class attendance' : 'All courses eligible'}</span>
            {subjectsAtRisk.length > 0 ? (
              <span className="badge badge-urgent">Action Required</span>
            ) : (
              <span className="badge badge-success">Clear</span>
            )}
          </div>
        </div>
      </div>

      {/* Subject-Wise Breakdown List */}
      <div className="dashboard-section-card">
        <div className="section-card-header">
          <div>
            <h3 className="section-title">Subject-Wise Attendance Breakdown</h3>
            <p className="section-subtitle">Real-time attendance logs per registered subject</p>
          </div>
          <span className="badge badge-info">{attendanceData.length} Subjects Tracked</span>
        </div>

        <div className="attendance-list">
          {attendanceData.map((item) => {
            const isBelowThreshold = item.percentage < 75;
            let badgeClass = 'badge-success';
            let barColor = 'var(--accent-emerald)';

            if (isBelowThreshold) {
              badgeClass = 'badge-urgent';
              barColor = 'var(--accent-rose)';
            } else if (item.percentage < 85) {
              badgeClass = 'badge-warning';
              barColor = 'var(--accent-amber)';
            }

            return (
              <div 
                key={item.id} 
                className={`attendance-item ${isBelowThreshold ? 'attendance-warning-card' : ''}`}
              >
                <div className="attendance-top-row">
                  <div>
                    <span className="course-code-badge">{item.code}</span>
                    <h4 className="subject-name" style={{ display: 'inline', marginLeft: '0.5rem' }}>
                      {item.subject}
                    </h4>
                    <span className="attendance-faculty">&bull; Faculty: {item.faculty}</span>
                  </div>

                  <div className="attendance-pct-group">
                    <span className={`badge ${badgeClass}`} style={{ fontSize: '0.85rem', padding: '4px 12px' }}>
                      {item.percentage.toFixed(1)}%
                    </span>
                  </div>
                </div>

                <div className="attendance-counts">
                  <span>Present: <strong>{item.presentClasses}</strong> / {item.totalClasses} Classes</span>
                  <span>Absent: <strong>{item.totalClasses - item.presentClasses}</strong> Sessions</span>
                </div>

                <div className="progress-bar-container" style={{ height: '8px', marginTop: '0.5rem' }}>
                  <div 
                    className="progress-bar-fill" 
                    style={{ width: `${item.percentage}%`, background: barColor }}
                  ></div>
                </div>

                {isBelowThreshold && (
                  <div className="attendance-warning-banner">
                    ⚠️ <strong>WARNING:</strong> Attendance is below the 75% mandatory threshold ({item.percentage.toFixed(1)}%). 
                    Attend the next 3 consecutive classes to clear shortage risk before semester exams.
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
