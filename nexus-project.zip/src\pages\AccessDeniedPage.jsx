import React from 'react';

export default function AccessDeniedPage({ onReturn }) {
  return (
    <div className="page-container" style={{ textAlign: 'center', paddingTop: '4rem', paddingBottom: '4rem' }}>
      <div className="card" style={{ maxWidth: '520px', margin: '0 auto', padding: '2.5rem', borderColor: 'rgba(244, 63, 94, 0.4)' }}>
        <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>🛡️</div>
        <h2 className="page-title" style={{ color: '#f87171' }}>Access Denied</h2>
        <p className="page-subtitle" style={{ marginBottom: '1.5rem' }}>
          You do not have the required authorization permissions to access this page section.
        </p>
        <span className="badge badge-urgent" style={{ marginBottom: '1.5rem', display: 'inline-block' }}>
          403 Forbidden &bull; Role Authorization Enforced
        </span>
        <div>
          <button 
            className="login-submit-btn" 
            style={{ width: 'auto', padding: '0.65rem 1.5rem' }}
            onClick={onReturn}
          >
            ← Return to Authorized Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}
