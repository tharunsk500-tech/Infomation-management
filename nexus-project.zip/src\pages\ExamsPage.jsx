import React from 'react';
import ExamsSection from '../components/ExamsSection';

export default function ExamsPage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h2 className="page-title">Examination Portal</h2>
        <p className="page-subtitle">Schedule, venues, seating arrangements, and syllabus guidelines.</p>
      </div>
      <ExamsSection />
    </div>
  );
}
