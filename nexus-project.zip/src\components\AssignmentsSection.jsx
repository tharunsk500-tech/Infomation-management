import React, { useState, useEffect } from 'react';
import { fetchAssignmentsApi, toggleAssignmentApi } from '../api/auth';

export default function AssignmentsSection({ showFilter = true, limit }) {
  const [assignments, setAssignments] = useState([]);
  const [filter, setFilter] = useState('All');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadAssignments() {
      try {
        const data = await fetchAssignmentsApi();
        setAssignments(data.assignments || []);
      } catch (err) {
        console.error('Assignments load error', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadAssignments();
  }, []);

  const toggleStatus = async (id) => {
    try {
      const data = await toggleAssignmentApi(id);
      setAssignments(data.assignments || []);
    } catch (err) {
      console.error('Assignment toggle error', err);
    }
  };

  const filteredAssignments = assignments.filter((item) => {
    if (filter === 'Pending') return item.status === 'Pending';
    if (filter === 'Completed') return item.status === 'Completed';
    return true;
  });

  const displayItems = limit ? filteredAssignments.slice(0, limit) : filteredAssignments;

  if (isLoading) {
    return (
      <div className="dashboard-section-card">
        <p style={{ color: 'var(--text-muted)' }}>Loading coursework data from server...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-section-card">
      <div className="section-card-header">
        <div>
          <h3 className="section-title">📝 Course Assignments</h3>
          <p className="section-subtitle">Track coursework, deadlines, and submission statuses</p>
        </div>

        {showFilter && (
          <div className="filter-button-group">
            {['All', 'Pending', 'Completed'].map((f) => (
              <button
                key={f}
                className={`filter-btn ${filter === f ? 'active' : ''}`}
                onClick={() => setFilter(f)}
              >
                {f}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="assignments-list">
        {displayItems.length === 0 ? (
          <div className="empty-state-box">No {filter.toLowerCase()} assignments found.</div>
        ) : (
          displayItems.map((item) => {
            const isCompleted = item.status === 'Completed';

            return (
              <div key={item.id} className={`assignment-item ${isCompleted ? 'assignment-completed' : ''}`}>
                <div className="assignment-main">
                  <div className="assignment-header-row">
                    <h4 className="assignment-title">{item.title}</h4>
                    <span className={`badge ${isCompleted ? 'badge-success' : 'badge-warning'}`}>
                      {item.status}
                    </span>
                    {item.priority && !isCompleted && (
                      <span className={`badge badge-${item.priorityType}`}>
                        {item.priority} Priority
                      </span>
                    )}
                  </div>

                  <p className="assignment-course">
                    <strong>Subject:</strong> {item.subject} ({item.code || 'CS'})
                  </p>

                  <div className="progress-bar-container">
                    <div
                      className="progress-bar-fill"
                      style={{
                        width: `${item.progress}%`,
                        background: isCompleted ? 'var(--accent-emerald)' : 'var(--primary)',
                      }}
                    ></div>
                  </div>
                  <div className="progress-label-row">
                    <span>Progress: {item.progress}%</span>
                    <span>Due Date: <strong>{item.dueDate}</strong></span>
                  </div>
                </div>

                <div className="assignment-action-col">
                  <button
                    className={`status-toggle-btn ${isCompleted ? 'btn-undo' : 'btn-complete'}`}
                    onClick={() => toggleStatus(item.id)}
                  >
                    {isCompleted ? '↩️ Mark Pending' : '✓ Mark Complete'}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
