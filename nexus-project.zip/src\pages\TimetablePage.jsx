import React from 'react';
import TimetableSection from '../components/TimetableSection';

export default function TimetablePage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h2 className="page-title">Full Academic Timetable</h2>
        <p className="page-subtitle">View and manage your weekly schedule, room locations, and lab sessions.</p>
      </div>
      <TimetableSection />
    </div>
  );
}
