import React, { useState, useRef, useEffect } from 'react';
import { queryAiApi } from '../api/auth';

export default function AIAssistantPage() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'assistant',
      text: `Hello! 👋 I am your server-authenticated Nexus Campus Assistant. How can I help you today? You can ask me about today's schedule, pending assignments, attendance alerts, exam dates, or campus announcements.`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef(null);

  const suggestedQuestions = [
    "What classes do I have today?",
    "What assignments are pending?",
    "Which subjects have low attendance?",
    "When is my next exam?",
    "What announcements are important?"
  ];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = async (textToSend) => {
    const text = textToSend || inputQuery;
    if (!text.trim()) return;

    const userMessage = {
      id: Date.now(),
      sender: 'user',
      text: text.trim(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputQuery('');
    setIsTyping(true);

    try {
      const data = await queryAiApi(text);
      const botMessage = {
        id: Date.now() + 1,
        sender: 'assistant',
        text: data.response || 'No response from assistant.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMessage]);
    } catch (err) {
      const errorMessage = {
        id: Date.now() + 1,
        sender: 'assistant',
        text: '⚠️ Error querying campus assistant. Please verify your session status.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="page-container ai-assistant-page">
      {/* Header Banner */}
      <div className="welcome-banner" style={{ marginBottom: '1.5rem', background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.18), rgba(6, 182, 212, 0.12))' }}>
        <div>
          <h2 className="welcome-title">🤖 Nexus AI Campus Assistant</h2>
          <p className="welcome-subtitle">
            Server-authenticated AI helper for student schedules, coursework, attendance alerts, and exam dates.
          </p>
        </div>
        <span className="badge badge-primary">Server API Active</span>
      </div>

      {/* Suggestion Chips */}
      <div className="suggestion-chips-container">
        <span className="suggestion-label">Suggested Queries:</span>
        <div className="chips-wrapper">
          {suggestedQuestions.map((q, idx) => (
            <button
              key={idx}
              className="suggestion-chip"
              onClick={() => handleSendMessage(q)}
            >
              💬 {q}
            </button>
          ))}
        </div>
      </div>

      {/* Main Chat Box */}
      <div className="chat-window-card">
        <div className="chat-messages-container">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`chat-message-row ${msg.sender === 'user' ? 'msg-user' : 'msg-assistant'}`}
            >
              <div className="msg-avatar">
                {msg.sender === 'user' ? 'U' : '🤖'}
              </div>
              <div className="msg-bubble-wrapper">
                <div className="msg-bubble">
                  {msg.text.split('\n').map((line, lineIdx) => {
                    const parts = line.split('**');
                    return (
                      <p key={lineIdx} style={{ margin: line ? '0.2rem 0' : '0.5rem 0' }}>
                        {parts.map((part, pIdx) =>
                          pIdx % 2 === 1 ? <strong key={pIdx}>{part}</strong> : part
                        )}
                      </p>
                    );
                  })}
                </div>
                <span className="msg-time">{msg.time}</span>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="chat-message-row msg-assistant">
              <div className="msg-avatar">🤖</div>
              <div className="msg-bubble-wrapper">
                <div className="msg-bubble typing-indicator">
                  <span></span><span></span><span></span>
                </div>
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Input Bar */}
        <div className="chat-input-bar">
          <input
            type="text"
            className="chat-input"
            placeholder="Ask about your classes, assignments, attendance, or exams..."
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={handleKeyPress}
          />
          <button 
            className="chat-send-btn" 
            onClick={() => handleSendMessage()}
            disabled={!inputQuery.trim() || isTyping}
          >
            Send ↗
          </button>
        </div>
      </div>
    </div>
  );
}
