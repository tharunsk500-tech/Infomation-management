import React from 'react';
import AssignmentsSection from '../components/AssignmentsSection';

export default function AssignmentsPage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h2 className="page-title">Assignments & Coursework Portal</h2>
        <p className="page-subtitle">View, filter, and track all upcoming and submitted assignments.</p>
      </div>
      <AssignmentsSection showFilter={true} />
    </div>
  );
}
