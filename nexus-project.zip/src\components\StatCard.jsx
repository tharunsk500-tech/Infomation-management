import React from 'react';

export default function StatCard({ item }) {
  return (
    <div className="stat-card">
      <div className="stat-header">
        <span className="stat-title">{item.title}</span>
        <span className="stat-icon">{item.icon}</span>
      </div>
      <div className="stat-value">{item.value}</div>
      <div className="stat-footer">
        <span className="stat-subtext">{item.subtext}</span>
        {item.badge && (
          <span className={`badge badge-${item.badgeType}`}>
            {item.badge}
          </span>
        )}
      </div>
    </div>
  );
}
