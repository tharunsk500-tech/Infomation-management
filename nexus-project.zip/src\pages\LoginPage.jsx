import React, { useState } from 'react';
import { loginApi } from '../api/auth';

export default function LoginPage({ onLoginSuccess }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSelectDemo = (roleKey) => {
    if (roleKey === 'student') {
      setEmail('student@nexus.demo');
      setPassword('NexusDemo123');
    } else if (roleKey === 'admin') {
      setEmail('admin@nexus.demo');
      setPassword('NexusAdmin123');
    }
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const trimmedEmail = email.trim();
    if (!trimmedEmail || !password) {
      setError('Please fill in both email and password fields.');
      return;
    }

    setIsLoading(true);

    try {
      const data = await loginApi(trimmedEmail, password);
      setIsLoading(false);
      if (data.user) {
        onLoginSuccess(data.user);
      }
    } catch (err) {
      setIsLoading(false);
      setError(err.message || 'Invalid email or password.');
    }
  };

  return (
    <div className="login-page-wrapper">
      <div className="login-card">
        <div className="login-brand-header">
          <div className="brand-logo" style={{ width: '52px', height: '52px', fontSize: '1.5rem' }}>N</div>
          <h1 className="login-title">Nexus Campus OS</h1>
          <p className="login-subtitle">Intelligent Digital Campus Management System</p>
        </div>

        {/* Demo Account Quick Selector */}
        <div className="demo-credentials-box">
          <div className="demo-box-header">
            <span>🔑 SERVER DEMO ACCOUNTS:</span>
          </div>
          <p style={{ fontSize: '0.75rem', color: 'var(--text-dim)', marginBottom: '0.6rem' }}>
            Select a demo account to verify server-side bcrypt authorization:
          </p>
          <div className="demo-role-buttons">
            <button 
              type="button" 
              className="demo-role-btn btn-student" 
              onClick={() => handleSelectDemo('student')}
            >
              👨‍🎓 Demo Student
            </button>
            <button 
              type="button" 
              className="demo-role-btn btn-admin" 
              onClick={() => handleSelectDemo('admin')}
            >
              🛡️ Demo Admin
            </button>
          </div>
        </div>

        {error && <div className="login-error-banner">{error}</div>}

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label className="form-label">Campus Email / Student ID</label>
            <input
              type="email"
              className="form-input"
              placeholder="student@nexus.demo or admin@nexus.demo"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={isLoading}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <div className="password-input-wrapper">
              <input
                type={showPassword ? 'text' : 'password'}
                className="form-input"
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
                required
              />
              <button
                type="button"
                className="password-toggle-btn"
                onClick={() => setShowPassword(!showPassword)}
                title={showPassword ? 'Hide Password' : 'Show Password'}
              >
                {showPassword ? '👁️‍🗨️' : '👁️'}
              </button>
            </div>
          </div>

          <button type="submit" className="login-submit-btn" disabled={isLoading}>
            {isLoading ? 'Verifying Credentials with Server...' : 'Sign In to Portal ➔'}
          </button>
        </form>

        <div className="login-card-footer">
          <span>Nexus v1.0 &bull; Express Session & Bcrypt Hashed Server Authentication</span>
        </div>
      </div>
    </div>
  );
}
