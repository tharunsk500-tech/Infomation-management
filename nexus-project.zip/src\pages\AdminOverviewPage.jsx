import React, { useState, useEffect } from 'react';
import { fetchAdminStatsApi } from '../api/auth';
import StatCard from '../components/StatCard';

export default function AdminOverviewPage() {
  const [adminStats, setAdminStats] = useState([]);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadAdminData() {
      try {
        const data = await fetchAdminStatsApi();
        setAdminStats(data.adminStats || []);
      } catch (err) {
        if (err.message === 'FORBIDDEN') {
          setError('403 Forbidden: Server denied access. Administrator role required.');
        } else {
          setError('Failed to load administrative analytics from server.');
        }
      } finally {
        setIsLoading(false);
      }
    }
    loadAdminData();
  }, []);

  if (isLoading) {
    return (
      <div className="page-container">
        <p style={{ color: 'var(--text-muted)' }}>Loading server-authorized administrative metrics...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="page-container" style={{ textAlign: 'center', paddingTop: '3rem' }}>
        <div className="card" style={{ maxWidth: '500px', margin: '0 auto', borderColor: 'rgba(244, 63, 94, 0.4)' }}>
          <div style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>🛡️</div>
          <h3 style={{ color: '#f87171', marginBottom: '0.5rem' }}>Server Security Guard</h3>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <h2 className="page-title">Campus Administration Overview</h2>
        <p className="page-subtitle">Server-authorized administrative monitoring panel for campus operations & portal metrics.</p>
      </div>

      <div className="banner-box" style={{ background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.15), rgba(99, 102, 241, 0.1))', borderColor: 'rgba(6, 182, 212, 0.3)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <h3 className="banner-title">Administrative Portal 👋</h3>
            <p className="banner-desc">All metric queries are validated server-side under the <strong>Administrator</strong> role.</p>
          </div>
          <span className="badge badge-info" style={{ fontSize: '0.85rem', padding: '6px 14px' }}>
            🛡️ SERVER-VERIFIED ADMIN
          </span>
        </div>
      </div>

      {/* Admin Stat Overview */}
      <div className="stats-grid">
        {adminStats.map((item) => (
          <StatCard key={item.id} item={item} />
        ))}
      </div>

      {/* Admin Operations Cards */}
      <div className="card-grid">
        <div className="card">
          <div className="card-title">🏫 Departmental Status</div>
          <p className="card-text">
            • CSE: 420 Students &bull; 92.4% Avg Attendance<br />
            • ECE: 380 Students &bull; 89.1% Avg Attendance<br />
            • Mech: 310 Students &bull; 86.5% Avg Attendance<br />
            • Civil: 310 Students &bull; 88.0% Avg Attendance
          </p>
        </div>

        <div className="card">
          <div className="card-title">🔐 Server Security Audit</div>
          <p className="card-text">
            • Authentication: HttpOnly Cookie Sessions<br />
            • Authorization: Server-enforced RBAC (requireRole)<br />
            • Password Hashing: Bcrypt (Salt Rounds: 10)<br />
            • Rate Limiting: 15 req/15min on Auth Endpoints
          </p>
        </div>
      </div>
    </div>
  );
}
