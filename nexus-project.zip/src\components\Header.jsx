import React from 'react';

export default function Header({ user, onLogout }) {
  const isTargetAdmin = user?.role === 'admin';

  return (
    <header className="nexus-header">
      <div className="brand-container">
        <div className="brand-logo">N</div>
        <div className="brand-text-group">
          <div className="brand-row">
            <h1 className="brand-title">Nexus</h1>
            <span className="brand-badge">Campus OS</span>
          </div>
          <span className="brand-subtitle">Intelligent Digital Campus</span>
        </div>
      </div>

      <div className="header-actions">
        <div className="system-status-chip">
          <span className="status-dot"></span>
          <span className="status-label">System Online</span>
        </div>

        {user && (
          <div className="student-profile-card">
            <div className="profile-avatar">{user.avatarInitials || 'U'}</div>
            <div className="profile-info">
              <span className="profile-name">{user.name}</span>
              <span className="profile-role">
                <span className={`badge ${isTargetAdmin ? 'badge-info' : 'badge-primary'}`} style={{ fontSize: '0.62rem', padding: '1px 6px', marginRight: '4px' }}>
                  {user.roleLabel || user.role?.toUpperCase()}
                </span>
                {user.department}
              </span>
            </div>
          </div>
        )}

        {onLogout && (
          <button className="logout-btn" onClick={onLogout} title="Sign Out of Session">
            🚪 Logout
          </button>
        )}
      </div>
    </header>
  );
}
