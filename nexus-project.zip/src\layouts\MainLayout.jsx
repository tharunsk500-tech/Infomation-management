import React from 'react';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';
import Footer from '../components/Footer';

export default function MainLayout({ children, activeTab, setActiveTab, user, onLogout }) {
  return (
    <div className="nexus-app">
      <Header user={user} onLogout={onLogout} />
      <div className="nexus-body">
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          userRole={user?.role} 
        />
        <main className="nexus-main-content">
          {children}
        </main>
      </div>
      <Footer />
    </div>
  );
}
