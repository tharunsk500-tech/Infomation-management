import React, { useState, useEffect } from 'react';
import MainLayout from './layouts/MainLayout';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import AdminOverviewPage from './pages/AdminOverviewPage';
import AccessDeniedPage from './pages/AccessDeniedPage';
import TimetablePage from './pages/TimetablePage';
import AttendancePage from './pages/AttendancePage';
import AssignmentsPage from './pages/AssignmentsPage';
import ExamsPage from './pages/ExamsPage';
import AnnouncementsPage from './pages/AnnouncementsPage';
import AIAssistantPage from './pages/AIAssistantPage';
import { checkAuth, logoutApi } from './api/auth';

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    // Verify server-side HttpOnly session on application mount
    async function initAuth() {
      try {
        const data = await checkAuth();
        if (data.authenticated && data.user) {
          setCurrentUser(data.user);
        } else {
          setCurrentUser(null);
        }
      } catch (e) {
        console.error('Session initialization error', e);
        setCurrentUser(null);
      } finally {
        setIsInitializing(false);
      }
    }
    initAuth();
  }, []);

  const handleLoginSuccess = (user) => {
    setCurrentUser(user);
    setActiveTab('dashboard');
  };

  const handleLogout = async () => {
    await logoutApi();
    setCurrentUser(null);
    setActiveTab('dashboard');
  };

  if (isInitializing) {
    return (
      <div className="login-page-wrapper">
        <div className="card" style={{ padding: '2rem', textAlign: 'center' }}>
          <div className="status-dot" style={{ margin: '0 auto 1rem', width: '12px', height: '12px' }}></div>
          <p style={{ color: 'var(--text-muted)' }}>Verifying Secure Session with Server...</p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  // Server-authorized Role Verification
  const renderContent = () => {
    const role = currentUser.role || 'student';

    // Role Guard: Admin Overview tab requires server-verified admin role
    if (activeTab === 'admin-overview' && role !== 'admin') {
      return <AccessDeniedPage onReturn={() => setActiveTab('dashboard')} />;
    }

    switch (activeTab) {
      case 'dashboard':
        return <DashboardPage />;
      case 'admin-overview':
        return <AdminOverviewPage />;
      case 'timetable':
        return <TimetablePage />;
      case 'attendance':
        return <AttendancePage />;
      case 'assignments':
        return <AssignmentsPage />;
      case 'exams':
        return <ExamsPage />;
      case 'announcements':
        return <AnnouncementsPage />;
      case 'ai-assistant':
        return <AIAssistantPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <MainLayout 
      activeTab={activeTab} 
      setActiveTab={setActiveTab}
      user={currentUser}
      onLogout={handleLogout}
    >
      {renderContent()}
    </MainLayout>
  );
}
