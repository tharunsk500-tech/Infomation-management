import React from 'react';

export default function Footer() {
  return (
    <footer className="nexus-footer">
      <div>Nexus Digital Campus OS &bull; Phase 1 Foundation</div>
      <div>Hackathon Project Build</div>
    </footer>
  );
}
