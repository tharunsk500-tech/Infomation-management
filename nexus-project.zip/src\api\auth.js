// Secure API Client using Server-side HttpOnly Cookie Authentication

export async function checkAuth() {
  try {
    const res = await fetch('/api/auth/me', { credentials: 'include' });
    if (!res.ok) return { authenticated: false, user: null };
    return await res.json();
  } catch (err) {
    console.error('Auth check error:', err);
    return { authenticated: false, user: null };
  }
}

export async function loginApi(email, password) {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ email, password }),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Authentication failed');
  }
  return data;
}

export async function logoutApi() {
  try {
    await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
  } catch (err) {
    console.error('Logout error:', err);
  }
}

export async function fetchStatsApi() {
  const res = await fetch('/api/dashboard/stats', { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch stats');
  return await res.json();
}

export async function fetchTimetableApi() {
  const res = await fetch('/api/dashboard/timetable', { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch timetable');
  return await res.json();
}

export async function fetchAttendanceApi() {
  const res = await fetch('/api/dashboard/attendance', { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch attendance');
  return await res.json();
}

export async function fetchAssignmentsApi() {
  const res = await fetch('/api/dashboard/assignments', { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch assignments');
  return await res.json();
}

export async function toggleAssignmentApi(id) {
  const res = await fetch(`/api/dashboard/assignments/${id}/toggle`, {
    method: 'POST',
    credentials: 'include',
  });
  if (!res.ok) throw new Error('Failed to update assignment');
  return await res.json();
}

export async function fetchExamsApi() {
  const res = await fetch('/api/dashboard/exams', { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch exams');
  return await res.json();
}

export async function fetchAnnouncementsApi() {
  const res = await fetch('/api/dashboard/announcements', { credentials: 'include' });
  if (!res.ok) throw new Error('Failed to fetch announcements');
  return await res.json();
}

export async function fetchAdminStatsApi() {
  const res = await fetch('/api/admin/stats', { credentials: 'include' });
  if (!res.ok) {
    if (res.status === 403) throw new Error('FORBIDDEN');
    throw new Error('Failed to fetch admin stats');
  }
  return await res.json();
}

export async function queryAiApi(query) {
  const res = await fetch('/api/ai/query', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ query }),
  });
  if (!res.ok) throw new Error('Failed to get AI response');
  return await res.json();
}
