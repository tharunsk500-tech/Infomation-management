import React from 'react';
import AnnouncementsSection from '../components/AnnouncementsSection';

export default function AnnouncementsPage() {
  return (
    <div className="page-container">
      <div className="page-header">
        <h2 className="page-title">Campus Announcements & Notices</h2>
        <p className="page-subtitle">Filter official updates, important alerts, and departmental notices.</p>
      </div>
      <AnnouncementsSection showFilter={true} />
    </div>
  );
}
