import express from 'express';
import session from 'express-session';
import bcrypt from 'bcryptjs';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// 1. Security Headers via Helmet
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:"],
        connectSrc: ["'self'"],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);

// 2. Body Parser & CORS
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const allowedOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
app.use(
  cors({
    origin: allowedOrigin,
    credentials: true,
  })
);

// 3. Rate Limiting for Security
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 15, // 15 attempts per IP
  message: { error: 'Too many login attempts. Please try again after 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
});

app.use('/api/', apiLimiter);

// 4. Session Security Management (HttpOnly cookies)
const sessionSecret = process.env.SESSION_SECRET || 'nexus_super_secret_session_key_2026_x89f';
app.use(
  session({
    name: 'nexus_sid',
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true, // Prevents JavaScript document.cookie access (XSS mitigation)
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  })
);

// 5. Server-Side Data & Password Hashes (Argon2id/Bcrypt Hashed)
// Pre-computing bcrypt hashes for server-side authorization
const SALT_ROUNDS = 10;
const studentHash = bcrypt.hashSync('NexusDemo123', SALT_ROUNDS);
const adminHash = bcrypt.hashSync('NexusAdmin123', SALT_ROUNDS);

const usersDb = [
  {
    id: 'user-001',
    email: 'student@nexus.demo',
    passwordHash: studentHash,
    name: 'Tharun',
    role: 'student',
    roleLabel: 'STUDENT',
    department: 'Computer Science & Engineering',
    year: 'Year 3 (Semester 5)',
    studentId: 'NX-2024-8842',
    avatarInitials: 'T',
    status: 'Active & Enrolled',
  },
  {
    id: 'user-002',
    email: 'admin@nexus.demo',
    passwordHash: adminHash,
    name: 'Dr. Admin',
    role: 'admin',
    roleLabel: 'ADMINISTRATOR',
    department: 'Campus Administration',
    year: 'System Overseer',
    studentId: 'NX-ADM-001',
    avatarInitials: 'A',
    status: 'System Administrator',
  },
];

// Server-side Encapsulated Datasets
let assignmentsDb = [
  { id: 101, title: 'OS Process Scheduler Simulation', subject: 'Operating Systems', code: 'CS302', dueDate: 'Today, 11:59 PM', status: 'Pending', priority: 'High', priorityType: 'urgent', progress: 85 },
  { id: 102, title: 'B-Tree Indexing & Query Optimization Report', subject: 'Database Management Systems', code: 'CS303', dueDate: 'Sep 28, 2026', status: 'Pending', priority: 'Medium', priorityType: 'medium', progress: 40 },
  { id: 103, title: 'Subnetting & IP Routing Lab Exercise', subject: 'Computer Networks', code: 'CS304', dueDate: 'Oct 2, 2026', status: 'Pending', priority: 'Normal', priorityType: 'normal', progress: 10 },
  { id: 104, title: 'Binary Search Tree Implementation', subject: 'Data Structures & Algorithms', code: 'CS301', dueDate: 'Sep 20, 2026', status: 'Completed', priority: 'High', priorityType: 'success', progress: 100 },
  { id: 105, title: 'Supervised Learning Regression Notebook', subject: 'Machine Learning & AI Basics', code: 'CS305', dueDate: 'Sep 15, 2026', status: 'Completed', priority: 'Medium', priorityType: 'success', progress: 100 },
];

const timetableDb = [
  { id: 1, subject: 'Data Structures & Algorithms', code: 'CS301', time: '09:00 AM - 10:30 AM', room: 'Lab 204 (Tech Block)', faculty: 'Dr. A. Sharma', status: 'Completed', statusType: 'success', isCurrent: false, isNext: false, type: 'Lab & Practical' },
  { id: 2, subject: 'Operating Systems', code: 'CS302', time: '11:00 AM - 12:30 PM', room: 'Lecture Hall 3B', faculty: 'Prof. R. Verma', status: 'In Progress', statusType: 'primary', isCurrent: true, isNext: false, type: 'Theory Lecture' },
  { id: 3, subject: 'Database Management Systems', code: 'CS303', time: '01:30 PM - 03:00 PM', room: 'Tech Block 102', faculty: 'Dr. K. Patel', status: 'Upcoming', statusType: 'secondary', isCurrent: false, isNext: true, type: 'Interactive Workshop' },
  { id: 4, subject: 'Computer Networks', code: 'CS304', time: '03:15 PM - 04:30 PM', room: 'NetLab 4', faculty: 'Prof. S. Rao', status: 'Upcoming', statusType: 'secondary', isCurrent: false, isNext: false, type: 'Theory & Tutorial' },
];

const attendanceDb = [
  { id: 1, subject: 'Data Structures & Algorithms', code: 'CS301', faculty: 'Dr. A. Sharma', presentClasses: 28, totalClasses: 30, percentage: 93.3 },
  { id: 2, subject: 'Operating Systems', code: 'CS302', faculty: 'Prof. R. Verma', presentClasses: 25, totalClasses: 30, percentage: 83.3 },
  { id: 3, subject: 'Machine Learning & AI Basics', code: 'CS305', faculty: 'Dr. M. Gupta', presentClasses: 16, totalClasses: 24, percentage: 66.7 },
  { id: 4, subject: 'Database Management Systems', code: 'CS303', faculty: 'Dr. K. Patel', presentClasses: 27, totalClasses: 30, percentage: 90.0 },
  { id: 5, subject: 'Computer Networks', code: 'CS304', faculty: 'Prof. S. Rao', presentClasses: 26, totalClasses: 30, percentage: 86.7 },
];

const examsDb = [
  { id: 201, subject: 'Operating Systems Mid-Term', code: 'CS302', date: 'Oct 1, 2026', time: '10:00 AM - 12:00 PM', room: 'Main Examination Hall A', syllabus: 'Units 1 to 3 (Processes, Threads, CPU Scheduling, Memory)', weightage: '30% Weightage' },
  { id: 202, subject: 'Data Structures Practical Exam', code: 'CS301', date: 'Oct 5, 2026', time: '02:00 PM - 05:00 PM', room: 'Computer Center Lab 2', syllabus: 'Trees, Graphs, Sorting & Hashing Algorithms', weightage: '20% Weightage' },
  { id: 203, subject: 'Database Systems Written Quiz', code: 'CS303', date: 'Oct 12, 2026', time: '09:00 AM - 10:00 AM', room: 'Tech Hall 102', syllabus: 'ER Modeling, Normalization (1NF to BCNF) & SQL Joins', weightage: '15% Weightage' },
];

const announcementsDb = [
  { id: 301, title: 'Nexus Campus Hackathon 2026 Registration Open', category: 'Hackathon', categoryType: 'highlight', date: 'Sep 25, 2026', author: 'Innovation Cell', isImportant: true, summary: 'Register your team for the annual 36-hour campus tech hackathon. Win exciting prizes and incubation opportunities.' },
  { id: 302, title: 'Central Library Extended Hours for Mid-Terms', category: 'Academic', categoryType: 'info', date: 'Sep 24, 2026', author: 'Library Administration', isImportant: true, summary: 'The main campus library will remain open 24/7 starting next Monday to support students during mid-term preparations.' },
  { id: 303, title: 'Scheduled Campus Wi-Fi & Portal Maintenance', category: 'Notice', categoryType: 'warning', date: 'Sep 22, 2026', author: 'IT Infrastructure Team', isImportant: false, summary: 'Network maintenance will occur on Saturday from 2:00 AM to 4:00 AM. Intermittent portal access may be experienced.' },
  { id: 304, title: 'Guest Lecture: Cloud Native Architectures', category: 'Event', categoryType: 'info', date: 'Sep 20, 2026', author: 'CS Department', isImportant: false, summary: 'Join us for an industry expert talk on microservices and Kubernetes in Auditorium B at 4:00 PM.' },
];

const adminStatsDb = [
  { id: 'students', title: 'Total Enrolled Students', value: '1,420', subtext: 'Across 6 Engineering Departments', badge: 'Active Term', badgeType: 'success', icon: '👥' },
  { id: 'alerts', title: 'Attendance Alerts (<75%)', value: '18 Students', subtext: 'Auto-notifications dispatched', badge: 'Action Required', badgeType: 'urgent', icon: '⚠️' },
  { id: 'assignments', title: 'Total Submissions Pending', value: '342 Files', subtext: 'Awaiting faculty evaluation', badge: 'In Review', badgeType: 'warning', icon: '📥' },
  { id: 'system', title: 'Campus Network Status', value: '99.98% Uptime', subtext: 'All portal microservices healthy', badge: 'Optimal', badgeType: 'primary', icon: '⚡' },
];

// 6. Server-Side Authorization Middleware
function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ error: 'Unauthorized: Session missing or expired.' });
  }
  next();
}

function requireRole(role) {
  return (req, res, next) => {
    if (!req.session || !req.session.userRole || req.session.userRole !== role) {
      return res.status(403).json({ error: 'Forbidden: Insufficient privileges.' });
    }
    next();
  };
}

// 7. Authentication Endpoints
app.post('/api/auth/login', authLimiter, (req, res) => {
  const { email, password } = req.body;

  if (!email || !password || typeof email !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: 'Invalid email or password format.' });
  }

  const normalizedEmail = email.trim().toLowerCase();
  const user = usersDb.find((u) => u.email === normalizedEmail);

  if (!user) {
    // Generic error to prevent account enumeration
    return res.status(401).json({ error: 'Invalid credentials.' });
  }

  const isValidPassword = bcrypt.compareSync(password, user.passwordHash);

  if (!isValidPassword) {
    return res.status(401).json({ error: 'Invalid credentials.' });
  }

  // Regenerate session ID to prevent session fixation attacks
  req.session.regenerate((err) => {
    if (err) {
      return res.status(500).json({ error: 'Session initialization error.' });
    }

    req.session.userId = user.id;
    req.session.userRole = user.role;
    req.session.user = {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      roleLabel: user.roleLabel,
      department: user.department,
      year: user.year,
      studentId: user.studentId,
      avatarInitials: user.avatarInitials,
    };

    return res.json({
      message: 'Authentication successful.',
      user: req.session.user,
    });
  });
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Logout error.' });
    }
    res.clearCookie('nexus_sid');
    return res.json({ message: 'Logged out successfully.' });
  });
});

app.get('/api/auth/me', (req, res) => {
  if (req.session && req.session.user) {
    return res.json({ authenticated: true, user: req.session.user });
  }
  return res.json({ authenticated: false, user: null });
});

// 8. Protected Data Endpoints (Authenticated)
app.get('/api/dashboard/stats', requireAuth, (req, res) => {
  const stats = [
    { id: "classes", title: "Today's Classes", value: "4 Sessions", subtext: "Current: Operating Systems (Hall 3B)", badge: "1 In Progress", badgeType: "primary", icon: "📚" },
    { id: "attendance", title: "Attendance Rate", value: "84.2%", subtext: "1 subject below 75% threshold", badge: "Attention Needed", badgeType: "warning", icon: "📊" },
    { id: "assignments", title: "Pending Assignments", value: "3 Pending", subtext: "OS Scheduler due tonight @ 11:59 PM", badge: "1 Urgent", badgeType: "urgent", icon: "📝" },
    { id: "exams", title: "Upcoming Exams", value: "2 Scheduled", subtext: "OS Mid-Term starts Oct 1, 2026", badge: "5 Days Away", badgeType: "info", icon: "🎯" },
  ];
  res.json({ stats });
});

app.get('/api/dashboard/timetable', requireAuth, (req, res) => {
  res.json({ timetable: timetableDb });
});

app.get('/api/dashboard/attendance', requireAuth, (req, res) => {
  res.json({ attendance: attendanceDb });
});

app.get('/api/dashboard/assignments', requireAuth, (req, res) => {
  res.json({ assignments: assignmentsDb });
});

app.post('/api/dashboard/assignments/:id/toggle', requireAuth, (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    return res.status(400).json({ error: 'Invalid assignment ID' });
  }

  assignmentsDb = assignmentsDb.map((item) => {
    if (item.id === id) {
      const newStatus = item.status === 'Pending' ? 'Completed' : 'Pending';
      return {
        ...item,
        status: newStatus,
        progress: newStatus === 'Completed' ? 100 : 50,
      };
    }
    return item;
  });

  res.json({ assignments: assignmentsDb });
});

app.get('/api/dashboard/exams', requireAuth, (req, res) => {
  res.json({ exams: examsDb });
});

app.get('/api/dashboard/announcements', requireAuth, (req, res) => {
  res.json({ announcements: announcementsDb });
});

app.post('/api/ai/query', requireAuth, (req, res) => {
  const { query } = req.body;
  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'Query string required' });
  }

  const q = query.toLowerCase();
  let response = '';

  if (q.includes('class') || q.includes('schedule') || q.includes('timetable') || q.includes('today')) {
    const classList = timetableDb
      .map(
        (c, idx) =>
          `${idx + 1}. **${c.subject} (${c.code})**\n   • Time: ${c.time}\n   • Room: ${c.room}\n   • Faculty: ${c.faculty}\n   • Status: ${c.status}${c.isCurrent ? ' ⚡ (In Progress)' : ''}`
      )
      .join('\n\n');
    response = `📅 **Today's Class Schedule:**\n\nYou have **${timetableDb.length} sessions** scheduled today:\n\n${classList}`;
  } else if (q.includes('assignment') || q.includes('pending') || q.includes('due')) {
    const pending = assignmentsDb.filter((a) => a.status === 'Pending');
    if (pending.length === 0) {
      response = `🎉 Great news! You have no pending assignments right now. All coursework is completed!`;
    } else {
      const list = pending
        .map(
          (a, idx) =>
            `${idx + 1}. 📝 **${a.title}**\n   • Subject: ${a.subject} (${a.code})\n   • Due Date: **${a.dueDate}**\n   • Priority: ${a.priority} | Progress: ${a.progress}%`
        )
        .join('\n\n');
      response = `📝 **Pending Assignments Overview:**\n\nYou currently have **${pending.length} pending assignments**:\n\n${list}`;
    }
  } else if (q.includes('attendance') || q.includes('low') || q.includes('shortage')) {
    const lowAttendance = attendanceDb.filter((item) => item.percentage < 75);
    const totalAttended = attendanceDb.reduce((acc, curr) => acc + curr.presentClasses, 0);
    const totalConducted = attendanceDb.reduce((acc, curr) => acc + curr.totalClasses, 0);
    const overall = ((totalAttended / totalConducted) * 100).toFixed(1);

    response = `📊 **Attendance Summary:**\nYour overall campus attendance rate is **${overall}%** (${totalAttended}/${totalConducted} sessions).\n\n`;
    if (lowAttendance.length > 0) {
      const warningList = lowAttendance
        .map(
          (item) =>
            `🚨 **${item.subject} (${item.code})**\n   • Attendance: **${item.percentage.toFixed(1)}%** (${item.presentClasses}/${item.totalClasses} classes)\n   • Faculty: ${item.faculty}\n   • Status: ⚠️ Below 75% threshold! Need to attend next 3 classes.`
        )
        .join('\n\n');
      response += `⚠️ **Low Attendance Warning (${lowAttendance.length} subject):**\n\n${warningList}`;
    } else {
      response += `✅ All your subjects are currently above the 75% mandatory threshold!`;
    }
  } else if (q.includes('exam') || q.includes('test') || q.includes('quiz') || q.includes('mid-term')) {
    const nextExam = examsDb[0];
    const examList = examsDb
      .map(
        (e, idx) =>
          `${idx + 1}. 🎯 **${e.subject} (${e.code})**\n   • Date & Time: **${e.date} (${e.time})**\n   • Venue: ${e.room}\n   • Scope: ${e.syllabus} (${e.weightage})`
      )
      .join('\n\n');
    response = `🎯 **Examination Schedule:**\n\nYour next exam is **${nextExam.subject}** on **${nextExam.date}** at **${nextExam.time}** in **${nextExam.room}**.\n\n**All Scheduled Exams (${examsDb.length}):**\n\n${examList}`;
  } else if (q.includes('announcement') || q.includes('important') || q.includes('notice')) {
    const important = announcementsDb.filter((a) => a.isImportant);
    const list = important
      .map(
        (a, idx) =>
          `${idx + 1}. 📢 **${a.title}**\n   • Category: ${a.category} | Date: ${a.date}\n   • Publisher: ${a.author}\n   • Details: ${a.summary}`
      )
      .join('\n\n');
    response = `📢 **Important Campus Announcements:**\n\n${list}`;
  } else {
    response = `🤖 I am your server-authenticated Nexus AI Campus Assistant. I can answer questions regarding your classes, pending assignments, attendance warnings, exam schedules, and important announcements.`;
  }

  res.json({ response });
});

// 9. Protected Admin Endpoints (Require Auth AND Admin Role)
app.get('/api/admin/stats', requireAuth, requireRole('admin'), (req, res) => {
  res.json({ adminStats: adminStatsDb });
});

// 10. Serve Static Production Build
const distPath = path.join(__dirname, '../dist');
app.use(express.static(distPath));

app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  res.sendFile(path.join(distPath, 'index.html'));
});

// 11. Generic Production Error Handler
app.use((err, req, res, next) => {
  console.error('[SERVER ERROR]', err.message);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  console.log(`[NEXUS SERVER] Secure authentication server running on port ${PORT}`);
});
