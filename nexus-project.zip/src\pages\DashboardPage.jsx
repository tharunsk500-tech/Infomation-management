import React from 'react';
import { dashboardStats, studentProfile } from '../data/demoData';
import StatCard from '../components/StatCard';
import TimetableSection from '../components/TimetableSection';
import AssignmentsSection from '../components/AssignmentsSection';
import ExamsSection from '../components/ExamsSection';
import AnnouncementsSection from '../components/AnnouncementsSection';

export default function DashboardPage() {
  return (
    <div className="page-container dashboard-page">
      {/* Welcome Banner */}
      <div className="welcome-banner">
        <div className="welcome-text">
          <h2 className="welcome-title">Welcome back, {studentProfile.name}! 👋</h2>
          <p className="welcome-subtitle">
            Here is your daily academic overview for <strong>{studentProfile.department}</strong>.
          </p>
        </div>
        <div className="welcome-meta-pill">
          <span>Student ID: {studentProfile.studentId}</span>
          <span className="dot-sep">&bull;</span>
          <span className="status-highlight">{studentProfile.status}</span>
        </div>
      </div>

      {/* 4 Dashboard Overview Stat Cards */}
      <div className="stats-grid">
        {dashboardStats.map((item) => (
          <StatCard key={item.id} item={item} />
        ))}
      </div>

      {/* Main Dashboard 2-Column Grid Layout */}
      <div className="dashboard-grid-layout">
        <div className="grid-main-column">
          <TimetableSection />
          <AssignmentsSection />
        </div>

        <div className="grid-side-column">
          <ExamsSection />
          <AnnouncementsSection />
        </div>
      </div>
    </div>
  );
}
